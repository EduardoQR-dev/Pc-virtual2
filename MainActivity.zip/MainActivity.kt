package com.pcvirtual.app

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextClock
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var desktop: FrameLayout
    private var windowCount = 0

    private val apps = listOf(
        Triple("🌐", "Navegador", "Aqui vai o navegador (Etapa 2)."),
        Triple("🎮", "Jogos", "Aqui vai a lista de jogos GBA e NDS (Etapa 3)."),
        Triple("☁️", "Cloud Game", "Aqui vai o cloud game (Etapa 4)."),
        Triple("📁", "Arquivos", "Aqui vai o gerenciador de arquivos.")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideBars()

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        desktop = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF1E3C72.toInt(), 0xFF2A5298.toInt())
            )
        }
        root.addView(desktop, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        root.addView(buildTaskbar(), LinearLayout.LayoutParams(MATCH_PARENT, dp(44)))
        setContentView(root)

        val icons = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        apps.forEach { (emoji, name, body) -> icons.addView(buildIcon(emoji, name, body)) }
        desktop.addView(icons, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
    }

    private fun buildIcon(emoji: String, name: String, body: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            setOnClickListener { openWindow(name, body) }
        }
        box.addView(TextView(this).apply {
            text = emoji
            textSize = 26f
            gravity = Gravity.CENTER
        })
        box.addView(TextView(this).apply {
            text = name
            textSize = 11f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        box.layoutParams = LinearLayout.LayoutParams(dp(76), WRAP_CONTENT)
        return box
    }

    private fun openWindow(title: String, body: String) {
        val win = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(10).toFloat()
            }
            clipToOutline = true
            elevation = dp(8).toFloat()
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF2B2B3A.toInt())
            setPadding(dp(12), 0, 0, 0)
        }
        bar.addView(TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 13f
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        bar.addView(TextView(this).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setOnClickListener { desktop.removeView(win) }
        }, LinearLayout.LayoutParams(dp(40), dp(32)))
        win.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, dp(32)))

        win.addView(TextView(this).apply {
            text = body
            setTextColor(Color.DKGRAY)
            textSize = 14f
            setPadding(dp(16), dp(16), dp(16), dp(16))
        })

        var dX = 0f
        var dY = 0f
        bar.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    win.bringToFront()
                    dX = win.x - e.rawX
                    dY = win.y - e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    win.x = e.rawX + dX
                    win.y = e.rawY + dY
                }
            }
            true
        }
        win.setOnClickListener { win.bringToFront() }

        desktop.addView(win, FrameLayout.LayoutParams(dp(380), dp(220)))
        val step = windowCount % 5
        win.x = dp(110 + 28 * step).toFloat()
        win.y = dp(12 + 28 * step).toFloat()
        windowCount++
    }

    private fun buildTaskbar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF111827.toInt())
            setPadding(dp(8), 0, dp(12), 0)
        }
        val start = TextView(this).apply {
            text = "⊞ Iniciar"
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
        }
        start.setOnClickListener { v ->
            val menu = PopupMenu(this, v)
            apps.forEachIndexed { i, a -> menu.menu.add(0, i, i, a.first + " " + a.second) }
            menu.setOnMenuItemClickListener { item ->
                val a = apps[item.itemId]
                openWindow(a.second, a.third)
                true
            }
            menu.show()
        }
        bar.addView(start, LinearLayout.LayoutParams(WRAP_CONTENT, MATCH_PARENT))
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        bar.addView(TextClock(this).apply {
            format24Hour = "HH:mm"
            format12Hour = "HH:mm"
            setTextColor(Color.WHITE)
            textSize = 14f
        })
        return bar
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
